<?php
// PUTRA RAMADAN
// 2255201005
// Write your code below:
$name = "Hello I am a variable!";
$language = "Oh hi. I'm also a variable.";
 $thing = "variables";
echo "I love concatenating " . $name ;
$food = "burgers";
echo "\nI love " .$language;