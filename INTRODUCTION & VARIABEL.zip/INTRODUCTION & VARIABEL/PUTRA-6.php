<?php
// PUTRA RAMADAN 
// 2255201005
// Fill in the blanks in the code below:
  $noun = "pensil";
  $adjective = "baik";
  $verb = "menggambar";

  echo "The world's most beloved $noun was very $noun and loved to $verb every single day.";


//Fix the code below and uncomment it:

  echo "\nI have always been obsessed with {$noun}. I'= {$adjective}.I'= always {$verb}.";