<?php
// PUTRA RAMADAN 
// 2255201005
  $movie = "air mata di ujung sajadah";
// Add your code here:


$old_favorite = $movie;
  echo "I'm a fickle person, my favorite movie used to be $movie.";
  
// Add a statement here:
  
$movie = "putra 2004";
  echo "\nBut now my favorite is $movie.";
  
// Add a statement below:
$old_favorite = "putra 2004";
  echo "\nBut now my favorite is $old_favorite.";