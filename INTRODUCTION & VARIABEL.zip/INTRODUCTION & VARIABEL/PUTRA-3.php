<?php
// PUTRA RAMADAN
// 2255201005
// Write your code below:   
echo "Code" . "cademy";


  //echo "\nMy name is:" 
 echo "\nMy name is:" . " putra";
echo "\n". "tur". "duck"."en";