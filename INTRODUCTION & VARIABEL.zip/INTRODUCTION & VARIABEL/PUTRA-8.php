<?php
// PUTRA RAMADAN 
// 2255201005
  echo "I'm going on a picnic!";

  $sentence = "\nI'm going on a picnic, and I'm taking apples";

$sentence .= ", bobo";
$sentence .= ", cacing";
  echo $sentence;

// Write your code below: