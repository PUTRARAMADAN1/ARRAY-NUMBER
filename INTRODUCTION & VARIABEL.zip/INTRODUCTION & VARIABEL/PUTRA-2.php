<?php
// PUTRA RAMADAN
// 2255201005
// Write your code below:
 echo "1. Teach PHP";
 echo "\n2. Eat breakfast";
 echo "\n3. Learn to have \"fun\"";
  
 
